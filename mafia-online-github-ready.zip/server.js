const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

const rooms = new Map();

io.on("connection", (socket) => {
  socket.on("joinGame", ({ name, room = "main" }) => {
    name = String(name || "بازیکن").trim().slice(0, 20);
    room = String(room || "main").trim().slice(0, 20);

    socket.join(room);

    if (!rooms.has(room)) rooms.set(room, new Map());
    rooms.get(room).set(socket.id, name);

    const players = [...rooms.get(room).values()];
    io.to(room).emit("players", players);
    socket.emit("system", `به اتاق ${room} وارد شدی.`);
  });

  socket.on("chat", ({ room = "main", message }) => {
    const text = String(message || "").trim().slice(0, 300);
    if (!text) return;

    const name = rooms.get(room)?.get(socket.id) || "بازیکن";
    io.to(room).emit("chat", { name, message: text });
  });

  socket.on("disconnect", () => {
    for (const [room, players] of rooms) {
      if (players.delete(socket.id)) {
        io.to(room).emit("players", [...players.values()]);
        if (players.size === 0) rooms.delete(room);
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Mafia Online running on port ${PORT}`);
});
